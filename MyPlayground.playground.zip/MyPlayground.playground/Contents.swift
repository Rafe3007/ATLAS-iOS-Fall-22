import UIKit
import Foundation

//let = constant vars
let greeting1: Double = 1.0

let greeting: String
greeting1 = "Hello, world"

struct Thing {
    var name: String
}

typealias Coordinate = (x: Int, y: Int)
var Coordinate: Coordinate = (x: 0, y: 20)

// Tuple
var coord = (x: 0,y: 20)

coord.0
coord.1
//OR
coord.x
coord.y

print(coord)

//func addNumber(number)   <-- how to define functions

enum CardinalDirection: String {
    case: north, east, south, west
}

var direction = CardinalDirection.north

switch direction {
case .north, .south:
    print("Verticle")
case .east, .west:
    print("Horizontal")
}

struct Person {
    var firstName: String
    var lastName: String
}

let me = Person(firstName: "Ramon", lastName: "Fernandez")

class Human {
    var firstName: String
    var lastName: String
    
    init() {
        firstName = ""
        lastName = ""
    }
}

Human()

var list: Array<Int> = [0,1,2,4,53]
//OR (shorthand)
var list1: [Int] = [1,3,1,34,4]

list.append(2)
list.append(3)

//A set is not ordered and can not have duplicates (unique values)

var dict = [Int:String]()
var dict1 = Dictionary<Int:String>()

dict[2] = "Two"
dict[3] = "Three"

dict[4] // NIL
dict[2] // "Two"

//The -> states the return type of the functions
func doStuff() -> Void {}

//Labels
func math(_ numberL Int, other: Int) -> Int {
    return number + other
}
math(2, other: 4)

